export interface ImageFile {
  file?: File;
  base64: string;
  mimeType: string;
}